export const ResumeTitle = ({ title }: { title: string }) => {
  return <h5 className="text-2xl text-resume-800">{title}</h5>;
};
